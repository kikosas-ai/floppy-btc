# 🪙 Flappy Bitcoin — Android App

## ▶️ HOW TO INSTALL ON ANDROID (2 Easy Methods)

---

### METHOD 1 — Chrome "Add to Home Screen" (Easiest, No Downloads Needed)

1. **Open the game file** on your Android phone
   - Transfer `index.html` to your phone via USB, WhatsApp, Google Drive, or email
   - Open it with **Google Chrome**

2. **Tap the 3-dot menu** (⋮) in Chrome → tap **"Add to Home Screen"**

3. **Tap "Add"** — the Flappy Bitcoin icon appears on your home screen!

4. Launch it from the home screen — it opens **fullscreen like a native app** ✅

---

### METHOD 2 — Host on GitHub Pages (Free, Shareable Link)

1. Create a free account at **github.com**
2. Create a new repository (e.g. `flappy-bitcoin`)
3. Upload all 3 files: `index.html`, `manifest.json`, `sw.js`
4. Go to **Settings → Pages → Deploy from main branch**
5. Your game is live at: `https://yourusername.github.io/flappy-bitcoin`
6. Open that link on any Android phone and "Add to Home Screen"

---

### METHOD 3 — Convert to APK (Advanced)

Use **PWABuilder** (free, by Microsoft):
1. Host the files on GitHub Pages (Method 2)
2. Go to **pwabuilder.com**
3. Enter your GitHub Pages URL
4. Click **"Build My PWA"** → choose **Android**
5. Download the `.apk` file
6. Install on Android (enable "Unknown Sources" in Settings)

---

## 🎮 HOW TO PLAY

| Action | Control |
|--------|---------|
| Flap   | Tap anywhere on screen |
| Start  | Tap LAUNCH button |
| Restart | Tap TRY AGAIN |

## 🏆 SCORING

- **+1 point** per pipe cleared
- **🪙 Collect ₿ coins** for bonus
- **Combo multiplier** for consecutive pipes!
- Best score is **saved automatically**

## 📁 FILES

| File | Purpose |
|------|---------|
| `index.html` | The entire game |
| `manifest.json` | Makes it installable as an app |
| `sw.js` | Enables offline play |

---

*Made with ₿ — To The Moon! 🚀*
